# First line = 5 numbers
  m n v c w
  
m : integer; ! # stops
 
n : integer; ! # students
  
v : integer; ! # vehicles
  
c : integer; ! Capacity of the buses
  
w : real;    ! maximum walking distance for students

# 

Next line = 2 numbers
  x y
  
x : real ; ! Depot x coordinates  
  
y : real ; ! Depot y coordinates  

# 

Next m lines = 2 numbers
  x y
  
x : real ; ! Stop x coordinates  
  
y : real ; ! Stop y coordinates  

# 

Next n lines = 2 numbers
  x y
  
x : real ; ! Student location x coordinates  
  
y : real ; ! Student location y coordinates 